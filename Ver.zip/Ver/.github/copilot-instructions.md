<!-- Use this file to provide workspace-specific custom instructions to Copilot. For more details, visit https://code.visualstudio.com/docs/copilot/copilot-customization#_use-a-githubcopilotinstructionsmd-file -->

# Project Instructions

This is a Bootstrap-based static web page for driver license verification with selfie capture functionality. The application allows users to take a selfie while holding their driver's license for verification purposes. The submitted photos are saved and sent via email.

Key features:
- Bootstrap for responsive design
- Webcam integration for selfie capture
- File upload for driver's license
- Email functionality to send verification data
