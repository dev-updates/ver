// Driver License Verification with Selfie JavaScript

// Elements
const form = document.getElementById('verificationForm');
const startCameraBtn = document.getElementById('startCamera');
const capturePhotoBtn = document.getElementById('capturePhoto');
const retakePhotoBtn = document.getElementById('retakePhoto');
const cameraStream = document.getElementById('cameraStream');
const captureCanvas = document.getElementById('captureCanvas');
const capturedPhoto = document.getElementById('capturedPhoto');
const cameraPlaceholder = document.getElementById('cameraPlaceholder');
const cameraOverlay = document.getElementById('cameraOverlay');
const licenseFile = document.getElementById('licenseFile');
const licensePreview = document.getElementById('licensePreview');
const licenseImage = document.getElementById('licenseImage');
const selfieData = document.getElementById('selfieData');
const submitBtn = document.getElementById('submitBtn');
const termsCheck = document.getElementById('termsCheck');

// Global variables
let stream = null;
let hasCapturedSelfie = false;
let hasLicenseImage = false;

// Initialize EmailJS
(function() {
    // Replace with your EmailJS public key when using in production
    // Sign up at https://www.emailjs.com/ to get your API keys
    emailjs.init("YOUR_EMAILJS_PUBLIC_KEY");
    
    // For demo purposes, we'll just log the data that would be sent
    console.log("EmailJS initialized for demo purposes");
})();

// Event Listeners
document.addEventListener('DOMContentLoaded', function() {
    // Start camera button
    startCameraBtn.addEventListener('click', startCamera);
    
    // Capture photo button
    capturePhotoBtn.addEventListener('click', capturePhoto);
    
    // Retake photo button
    retakePhotoBtn.addEventListener('click', retakePhoto);
    
    // License file upload
    licenseFile.addEventListener('change', handleLicenseUpload);
    
    // Form submission
    form.addEventListener('submit', handleSubmit);
    
    // Terms checkbox for enabling submit button
    termsCheck.addEventListener('change', updateSubmitButton);
});

// Start camera function
async function startCamera() {
    try {
        // Request access to webcam
        stream = await navigator.mediaDevices.getUserMedia({ 
            video: { 
                facingMode: "user",
                width: { ideal: 1280 },
                height: { ideal: 720 }
            },
            audio: false 
        });
        
        // Show and set up video element
        cameraStream.srcObject = stream;
        cameraStream.classList.remove('d-none');
        cameraPlaceholder.classList.add('d-none');
        cameraOverlay.classList.remove('d-none');
        
        // Show capture button and hide start button
        capturePhotoBtn.classList.remove('d-none');
        startCameraBtn.classList.add('d-none');
        
        // Hide any previously captured photo
        capturedPhoto.classList.add('d-none');
        
    } catch (err) {
        console.error("Error accessing camera:", err);
        alert("Error accessing camera. Please make sure you have given permission to use the camera and try again.");
    }
}

// Capture photo function
function capturePhoto() {
    // Set canvas dimensions to match video
    const width = cameraStream.videoWidth;
    const height = cameraStream.videoHeight;
    captureCanvas.width = width;
    captureCanvas.height = height;
    
    // Draw video frame to canvas
    const context = captureCanvas.getContext('2d');
    context.drawImage(cameraStream, 0, 0, width, height);
    
    // Convert canvas to data URL
    const photoData = captureCanvas.toDataURL('image/jpeg');
    
    // Display captured photo
    capturedPhoto.src = photoData;
    capturedPhoto.classList.remove('d-none');
    cameraStream.classList.add('d-none');
    cameraOverlay.classList.add('d-none');
    
    // Store photo data in hidden input for form submission
    selfieData.value = photoData;
    
    // Show retake button and hide capture button
    retakePhotoBtn.classList.remove('d-none');
    capturePhotoBtn.classList.add('d-none');
    
    // Stop camera stream
    stopCamera();
    
    // Update state and submit button
    hasCapturedSelfie = true;
    updateSubmitButton();
}

// Retake photo function
function retakePhoto() {
    // Hide captured photo
    capturedPhoto.classList.add('d-none');
    
    // Reset selfie data
    selfieData.value = '';
    hasCapturedSelfie = false;
    
    // Show start camera button again
    startCameraBtn.classList.remove('d-none');
    retakePhotoBtn.classList.add('d-none');
    
    // Update submit button state
    updateSubmitButton();
}

// Stop camera function
function stopCamera() {
    if (stream) {
        stream.getTracks().forEach(track => track.stop());
        stream = null;
    }
}

// Handle license file upload
function handleLicenseUpload(event) {
    const file = event.target.files[0];
    
    if (file) {
        // Create a FileReader to read the image
        const reader = new FileReader();
        reader.onload = function(e) {
            // Display the license image preview
            licenseImage.src = e.target.result;
            licensePreview.classList.remove('d-none');
            
            // Update state
            hasLicenseImage = true;
            updateSubmitButton();
        };
        reader.readAsDataURL(file);
    } else {
        licensePreview.classList.add('d-none');
        hasLicenseImage = false;
        updateSubmitButton();
    }
}

// Update submit button state
function updateSubmitButton() {
    // Enable submit button if terms are checked and a selfie is captured
    submitBtn.disabled = !(termsCheck.checked && hasCapturedSelfie);
}

// Handle form submission
function handleSubmit(event) {
    event.preventDefault();
    
    // Collect form data
    const formData = {
        name: document.getElementById('fullName').value,
        email: document.getElementById('email').value,
        phone: document.getElementById('phone').value,
        licenseNumber: document.getElementById('licenseNumber').value,
        selfie: selfieData.value,
        license: licenseImage.src || null
    };
    
    // Show loading state
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>Processing...';
    
    // For demo purposes, we'll simulate the email sending
    console.log("DEMO MODE: Email would be sent with the following data:", {
        to_email: "verification@example.com",
        from_name: formData.name,
        from_email: formData.email,
        subject: "Driver License Verification - " + formData.name,
        message: `Name: ${formData.name}\nEmail: ${formData.email}\nPhone: ${formData.phone}\nLicense Number: ${formData.licenseNumber}`,
        // Images would be attached
    });
        // Simulate successful submission
    setTimeout(() => {
        // Save data to localStorage and "server"
        saveVerificationData(formData);
        
        // Show success modal
        const successModal = new bootstrap.Modal(document.getElementById('successModal'));
        successModal.show();
        
        // Reset form
        form.reset();
        resetFormState();
    }, 1500);
    
    /* PRODUCTION CODE - Uncomment and configure for real email sending
    emailjs.send("default_service", "verification_template", {
        to_email: "verification@example.com",
        from_name: formData.name,
        from_email: formData.email,
        subject: "Driver License Verification - " + formData.name,
        message: `
            Name: ${formData.name}
            Email: ${formData.email}
            Phone: ${formData.phone}
            License Number: ${formData.licenseNumber}
        `,
        selfie_image: formData.selfie,
        license_image: formData.license
    })
    .then(function(response) {
        console.log("SUCCESS!", response.status, response.text);
        
        // Save data to localStorage for demo purposes
        saveVerificationData(formData);
        
        // Show success modal
        const successModal = new bootstrap.Modal(document.getElementById('successModal'));
        successModal.show();
        
        // Reset form
        form.reset();
        resetFormState();
    })
    .catch(function(error) {
        console.log("FAILED...", error);
        alert("There was an error submitting your verification. Please try again.");
        
        // Reset button state
        submitBtn.disabled = false;
        submitBtn.innerHTML = '<i class="fas fa-paper-plane me-2"></i>Submit Verification';
    });
    */
}

// Save verification data
function saveVerificationData(data) {
    // Get existing data from localStorage
    const existingData = JSON.parse(localStorage.getItem('verificationData')) || [];
    
    // Add timestamp to the data
    data.timestamp = new Date().toISOString();
    
    // Add to existing data
    existingData.push(data);
    
    // Save back to localStorage
    localStorage.setItem('verificationData', JSON.stringify(existingData));
    
    // Save data to server (in production this would call an API)
    saveToServer(data);
}

// Function to save data to the server/result folder
function saveToServer(data) {
    // For demonstration, create a formatted JSON string to show what would be saved
    const jsonData = {
        name: data.name,
        email: data.email,
        phone: data.phone,
        licenseNumber: data.licenseNumber,
        timestamp: data.timestamp,
        // The actual images would be stored as files on the server
        selfieImageSaved: "result/" + makeFileName(data.name, "selfie"),
        licenseImageSaved: data.license ? "result/" + makeFileName(data.name, "license") : null
    };
    
    console.log("Saving verification data to server:", jsonData);
    
    // In a real implementation, this would be an AJAX call to a server endpoint
    // that would save the images to the file system and data to a database
    
    // Example of how this would work with a server-side API:
    /*
    fetch('/api/save-verification', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            userData: {
                name: data.name,
                email: data.email,
                phone: data.phone,
                licenseNumber: data.licenseNumber,
                timestamp: data.timestamp
            },
            selfieImage: data.selfie,
            licenseImage: data.license
        })
    })
    .then(response => response.json())
    .then(result => {
        console.log("Data saved successfully:", result);
    })
    .catch(error => {
        console.error("Error saving data:", error);
    });
    */
    
    // For the demo, we'll simulate a successful save
    simulateSaveToResultFolder(data);
}

// Helper function to generate a clean filename
function makeFileName(name, type) {
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const cleanName = name.replace(/[^a-z0-9]/gi, '-').toLowerCase();
    return `${cleanName}-${type}-${timestamp}.jpg`;
}

// This is a simulation function since browser JavaScript cannot directly write to the file system
function simulateSaveToResultFolder(data) {
    // In a real server implementation, PHP, Node.js, or another backend language 
    // would handle the actual file writing process
    
    // 1. Create JSON file name
    const jsonFileName = makeFileName(data.name, "data").replace('.jpg', '.json');
    
    // 2. Prepare JSON content (excluding the large base64 image strings for readability)
    const jsonContent = {
        name: data.name,
        email: data.email,
        phone: data.phone,
        licenseNumber: data.licenseNumber,
        timestamp: data.timestamp,
        selfieImageFile: makeFileName(data.name, "selfie"),
        licenseImageFile: data.license ? makeFileName(data.name, "license") : null
    };
    
    // 3. Log what would be saved in a real implementation
    console.log(`Saving JSON data to: result/${jsonFileName}`);
    console.log(JSON.stringify(jsonContent, null, 2));
    
    // 4. For selfie image
    console.log(`Saving selfie image to: result/${makeFileName(data.name, "selfie")}`);
    
    // 5. For license image if exists
    if (data.license) {
        console.log(`Saving license image to: result/${makeFileName(data.name, "license")}`);
    }
    
    // In our demo, show a special message to the user explaining where data would be saved
    addResultMessage(jsonFileName, makeFileName(data.name, "selfie"), data.license ? makeFileName(data.name, "license") : null);
}

// Reset form state
function resetFormState() {
    // Reset button state
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<i class="fas fa-paper-plane me-2"></i>Submit Verification';
    
    // Reset images and camera state
    capturedPhoto.classList.add('d-none');
    cameraPlaceholder.classList.remove('d-none');
    licensePreview.classList.add('d-none');
    
    // Reset buttons
    startCameraBtn.classList.remove('d-none');
    capturePhotoBtn.classList.add('d-none');
    retakePhotoBtn.classList.add('d-none');
    
    // Reset state variables
    hasCapturedSelfie = false;
    hasLicenseImage = false;
    selfieData.value = '';
}

// Add message about saved files to the success modal
function addResultMessage(jsonFile, selfieFile, licenseFile) {
    // Get the modal body
    const modalBody = document.querySelector('#successModal .modal-body');
    
    // Create element for saved files info
    const savedFilesInfo = document.createElement('div');
    savedFilesInfo.className = 'mt-4 border-top pt-3';
    
    // Add title
    const title = document.createElement('h6');
    title.className = 'text-boa mb-3';
    title.innerHTML = '<i class="fas fa-save me-2"></i>Verification Data Saved';
    savedFilesInfo.appendChild(title);
    
    // Add file list
    const fileList = document.createElement('ul');
    fileList.className = 'list-group list-group-flush small';
    
    // Add JSON file
    const jsonItem = document.createElement('li');
    jsonItem.className = 'list-group-item d-flex justify-content-between align-items-center px-0';
    jsonItem.innerHTML = `
        <span><i class="fas fa-file-code text-primary me-2"></i>Client Data (JSON)</span>
        <span class="badge bg-light text-dark text-end text-truncate" style="max-width: 200px;">result/${jsonFile}</span>
    `;
    fileList.appendChild(jsonItem);
    
    // Add selfie image file
    const selfieItem = document.createElement('li');
    selfieItem.className = 'list-group-item d-flex justify-content-between align-items-center px-0';
    selfieItem.innerHTML = `
        <span><i class="fas fa-camera text-primary me-2"></i>Selfie Image</span>
        <span class="badge bg-light text-dark text-end text-truncate" style="max-width: 200px;">result/${selfieFile}</span>
    `;
    fileList.appendChild(selfieItem);
    
    // Add license image file if exists
    if (licenseFile) {
        const licenseItem = document.createElement('li');
        licenseItem.className = 'list-group-item d-flex justify-content-between align-items-center px-0';
        licenseItem.innerHTML = `
            <span><i class="fas fa-id-card text-primary me-2"></i>License Image</span>
            <span class="badge bg-light text-dark text-end text-truncate" style="max-width: 200px;">result/${licenseFile}</span>
        `;
        fileList.appendChild(licenseItem);
    }
    
    // Add list to saved files info
    savedFilesInfo.appendChild(fileList);
    
    // Add note about server-side storage
    const note = document.createElement('p');
    note.className = 'small text-muted mt-2 mb-0';
    note.textContent = 'In a production environment, these files would be securely stored on the server.';
    savedFilesInfo.appendChild(note);
    
    // Add the saved files info to the modal body
    modalBody.appendChild(savedFilesInfo);
}
