# Verification Results Folder

This folder contains client verification data saved by the Driver License Verification system.

## File Structure

For each verification submission, the following files are saved:

1. **JSON Data File**: Contains client information
   - Filename format: `[name]-data-[timestamp].json`
   - Contains: name, email, phone, license number, timestamp, and references to image files

2. **Selfie Image File**: Client's selfie with driver's license
   - Filename format: `[name]-selfie-[timestamp].jpg`

3. **License Image File** (if uploaded): Client's driver's license image
   - Filename format: `[name]-license-[timestamp].jpg`

## Note

In a real production environment, these files would be stored securely on the server with appropriate access controls and encryption.

## Sample Files

A sample set of files is included to demonstrate the structure.
