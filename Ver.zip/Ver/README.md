# Driver License Verification with Selfie

A Bootstrap-based static web page that allows users to take a selfie while holding their driver's license for verification purposes. The submitted photo is saved and sent via email.

## Features

- Responsive design using Bootstrap
- Webcam integration for selfie capture
- Driver's license upload option
- Email functionality to send verification data

## Setup

1. Clone this repository
2. Open `index.html` in your web browser
3. Allow camera permissions when prompted

## Technologies Used

- HTML5
- CSS3 (Bootstrap 5)
- JavaScript
- [EmailJS](https://www.emailjs.com/) for email functionality

## Usage

1. Open the verification page
2. Upload your driver's license or take a picture of it
3. Take a selfie while holding your driver's license
4. Fill in required information
5. Submit the form to complete verification
